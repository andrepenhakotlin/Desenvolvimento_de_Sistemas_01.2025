from django.utils.translation import gettext_lazy as _
from django.db import models

class TipoMarca(models.TextChoices):
    CEM = '100', _("100 metros")
    QUATROCENTOS = '400', _("400 metros")
    CINCO_KM = '5KM', _("5 Quilômetros")
    DEZ_KM = '10KM', _("10 Quilômetros")
    QUINZE_KM = '15KM', _("15 Quilômetros")
    VINTE = '20', _("20 Quilômetros")
    MEIA_MARATONA = 'MEIA', _("Meia Maratona")
    TRINTA_KM = '30KM', _("30 Quilômetros")
    MARATONA = 'M', _("Maratona")
    LONGA_DISTANCIA = 'LD', _("Maior Distância")
    LONGA_DURACAO = 'LD', _("Maior Duração")
