from django.utils.translation import gettext_lazy as _
from django.db import models

class TipoEquipamento(models.TextChoices):
    SNEAKER = 'S', _("Tenis")
    BIKE = 'B', _("Bike")
    SMART_DEVICE = 'SD', _("Dispositivo Inteligente")
