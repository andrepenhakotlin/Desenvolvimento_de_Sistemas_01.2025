from django.utils.translation import gettext_lazy as _
from django.db import models

class TipoEsporte(models.TextChoices):
    RUN = 'R', _("Corrriida")
    TRAIL_RUN = 'TR', _("Corrida de Trilha")
    WALK = 'B', _("Caminhada")
    HIIT = 'H', _("Treino de Alta Intensidade")
    STRENGTH = 'S', _("Treino de Força")
    CARDIO = 'C', _("Treino de Aerobico")
    SWIMMING = 'N', _("Natação")