from django.core.validators import MinLengthValidator, MaxLengthValidator
from .base_model import BaseModel
from django.db import models

class Record(BaseModel):
    nome = models.CharField(max_length=20, validators=[MinLengthValidator(2),MaxLengthValidator(20)])
    # tipo_marca = models.CharField()
    # tipo_esporte = models.CharField()
    # ritmo = models.TimeField() 
    # duracao = models.DurationField()

    def __str__(self):
        return self.nome